declare @i as integer
declare @total as integer
declare @tabSequence as integer
declare @ClientAdminCategoryLookup as bigint
declare @TenantId nvarchar(150)

declare @tmpAdminConfig table
(ID int identity,
TblID int,
TenantId nvarchar(150)
)

insert into @tmpAdminConfig (TblID, TenantId) select ID, TenantID from  Config_ClientAdminCategory where CategoryName like '%Governance%'

select @total = COUNT(*) from @tmpAdminConfig
set @i = 1
while @i <= @total
begin
 select @TenantId = TenantId from @tmpAdminConfig where Id = @i


IF NOT EXISTS (select Id from Config_ClientAdminConfigurationLists where ListName = 'HelpCard' and TenantID = @TenantID)
BEGIN

	select @ClientAdminCategoryLookup = Id from Config_ClientAdminCategory where TenantID = @TenantID and CategoryName = 'Document Management'

	select @tabSequence = TabSequence from Config_ClientAdminConfigurationLists where TenantID = @TenantID
		and ClientAdminCategoryLookup = @ClientAdminCategoryLookup

	set @tabSequence = @tabSequence + 1

	INSERT INTO [dbo].[Config_ClientAdminConfigurationLists]
			   ([ClientAdminCategoryLookup]
			   ,[Description]
			   ,[ListName]
			   ,[TabSequence]
			   ,[Title]
			   ,[TenantID]
			   ,[Created]
			   ,[Modified]
			   ,[Deleted]
			   ,[Attachments])
		 VALUES
			   (@ClientAdminCategoryLookup
			   ,'create and edit help cards'
			   ,'HelpCard'
			   ,@tabSequence
			   ,'Help Card'
			   , @TenantID
			   ,GETDATE()
			   ,GETDATE()
			   ,0
			   ,'')
	END


set @i = @i + 1
end