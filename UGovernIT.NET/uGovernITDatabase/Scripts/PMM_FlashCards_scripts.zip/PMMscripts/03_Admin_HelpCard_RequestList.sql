declare @i as integer
declare @total as integer

declare @TenantId nvarchar(150)

declare @tmpAdminConfig table
(ID int identity,
TblID int,
TenantId nvarchar(150)
)

insert into @tmpAdminConfig (TblID, TenantId) select ID, TenantID from  Config_ClientAdminCategory where CategoryName like '%Governance%'

select @total = COUNT(*) from @tmpAdminConfig
set @i = 1
while @i <= @total
begin
 select @TenantId = TenantId from @tmpAdminConfig where Id = @i


	IF NOT EXISTS (select Id from Config_Module_ModuleColumns where FieldName = 'TicketId' and CategoryName = 'HLP' and TenantID = @TenantID)
	BEGIN
	INSERT INTO [dbo].[Config_Module_ModuleColumns]
			   ([ColumnType]
			   ,[CustomProperties]
			   ,[DisplayForClosed]
			   ,[DisplayForReport]
			   ,[FieldDisplayName]
			   ,[FieldName]
			   ,[FieldSequence]
			   ,[IsAscending]
			   ,[IsDisplay]
			   ,[IsUseInWildCard]
			   ,[ShowInMobile]
			   ,[SortOrder]
			   ,[TextAlignmentChoice]
			   ,[Title]
			   ,[CategoryName]
			   ,[TenantID]
			   ,[Created]
			   ,[Modified]
			   ,[Deleted]
			   ,[Attachments]
			   )
		 VALUES
			   ('','',NULL, NULL ,'Help Card ID','TicketId',1, 0 ,1, 1
			   , 1
			   ,NULL
			   , NULL
			   ,NULL
			   , 'HLP'
			   , @TenantID
			   , GETDATE()
			   , GETDATE()
			   ,0
			   ,''
			   )
	END
	---------------------
	IF NOT EXISTS (select Id from Config_Module_ModuleColumns where FieldName = 'Title' and CategoryName = 'HLP' and TenantID = @TenantID)
	BEGIN
	INSERT INTO [dbo].[Config_Module_ModuleColumns]
			   ([ColumnType]
			   ,[CustomProperties]
			   ,[DisplayForClosed]
			   ,[DisplayForReport]
			   ,[FieldDisplayName]
			   ,[FieldName]
			   ,[FieldSequence]
			   ,[IsAscending]
			   ,[IsDisplay]
			   ,[IsUseInWildCard]
			   ,[ShowInMobile]
			   ,[SortOrder]
			   ,[TextAlignmentChoice]
			   ,[Title]
			   ,[CategoryName]
			   ,[TenantID]
			   ,[Created]
			   ,[Modified]
			   ,[Deleted]
			   ,[Attachments]
			   )
		 VALUES
		   ('','',NULL, NULL ,'Title','Title',2, 1 ,1, 1
           , 1
           ,1
           , NULL
           ,NULL
           , 'HLP'
           , @TenantID
           , GETDATE()
           , GETDATE()
           ,0
           ,NULL
           )
	END
	--------------------
	IF NOT EXISTS (select Id from Config_Module_ModuleColumns where FieldName = 'Category' and CategoryName = 'HLP' and TenantID = @TenantID)
	BEGIN
	INSERT INTO [dbo].[Config_Module_ModuleColumns]
			   ([ColumnType]
			   ,[CustomProperties]
			   ,[DisplayForClosed]
			   ,[DisplayForReport]
			   ,[FieldDisplayName]
			   ,[FieldName]
			   ,[FieldSequence]
			   ,[IsAscending]
			   ,[IsDisplay]
			   ,[IsUseInWildCard]
			   ,[ShowInMobile]
			   ,[SortOrder]
			   ,[TextAlignmentChoice]
			   ,[Title]
			   ,[CategoryName]
			   ,[TenantID]
			   ,[Created]
			   ,[Modified]
			   ,[Deleted]
			   ,[Attachments]
			   )
		 VALUES
		   ('','',NULL, NULL ,'Category','Category',3, 0 ,1, 0
           , 0
           ,NULL
           , NULL
           ,NULL
           , 'HLP'
           ,@TenantID
           , GETDATE()
           , GETDATE()
           ,0
           ,NULL
           )
	END


set @i = @i + 1
end