ALTER TABLE Config_Service_ServiceQuestions
ADD	[NavigationType] NVARCHAR (250)  NULL;


ALTER TABLE Config_Services
ADD [NavigationType] NVARCHAR (250)  NULL;

ALTER TABLE Config_Modules
ADD [NavigationType] NVARCHAR (250)  NULL;


ALTER TABLE Config_Module_ModuleStages
ADD [NavigationUrl]    NVARCHAR (max)  NULL,
	[NavigationType]    NVARCHAR (250)  NULL;

alter table Config_Module_ModuleStages
add [IconUrl] NVARCHAR(MAX) NULL