declare @i as integer
declare @total as integer

declare @TenantId nvarchar(150)

declare @tmpAdminConfig table
(ID int identity,
TblID int,
TenantId nvarchar(150)
)

insert into @tmpAdminConfig (TblID, TenantId) select ID, TenantID from  Config_ClientAdminCategory where CategoryName like '%Governance%'

select @total = COUNT(*) from @tmpAdminConfig
set @i = 1
while @i <= @total
begin
 select @TenantId = TenantId from @tmpAdminConfig where Id = @i


IF NOT EXISTS (select ID from Config_Modules where ModuleName = 'HLP' and TenantID = @TenantID)
BEGIN
INSERT INTO [dbo].[Config_Modules]
           ([ActionUserNotificationOnCancel]
           ,[ActionUserNotificationOnComment]
           ,[ActualHoursByUser]
           ,[EnableCloseOnHoldExpire]
           ,[AllowBatchClose]
           ,[AllowBatchCreate]
           ,[AllowBatchEditing]
           ,[AllowChangeType]
           ,[AllowDelete]
           ,[AllowDraftMode]
           ,[AllowEscalationFromList]
           ,[AllowReassignFromList]
           ,[AuthorizedToCreate]
           ,[AuthorizedToView]
           ,[AutoCreateDocumentLibrary]
           ,[CategoryName]
           ,[CloseChart]
           ,[CustomProperties]
           ,[DisableNewConfirmation]
           ,[EnableCache]
           ,[EnableEventReceivers]
           ,[EnableLayout]
           ,[EnableModule]
           ,[EnableModuleAgent]
           ,[EnableNewsOnHomePage]
           ,[EnableQuick]
           ,[EnableRMMAllocation]
           ,[EnableWorkflow]
           ,[HideWorkFlow]
           ,[InitiatorNotificationOnCancel]
           ,[InitiatorNotificationOnComment]
           ,[ItemOrder]
           ,[KeepItemOpen]
           ,[LastSequence]
           ,[LastSequenceDate]
           ,[ModuleAutoApprove]
           ,[ModuleDescription]
           ,[ModuleHoldMaxStage]
           ,[ModuleId]
           ,[ModuleName]
           ,[ModuleRelativePagePath]
           ,[ModuleTable]
           ,[ModuleType]
           ,[NavigationUrl]
           ,[OpenChart]
           ,[OwnerBindingChoice]
           ,[PreloadAllModuleTabs]
           ,[ReloadCache]
           ,[RequestorNotificationOnCancel]
           ,[RequestorNotificationOnComment]
           ,[ReturnCommentOptional]
           ,[ShortName]
           ,[ShowBottleNeckChart]
           ,[ShowComment]
           ,[ShowNextSLA]
           ,[ShowSummary]
           ,[StaticModulePagePath]
           ,[StoreEmails]
           ,[SyncAppsToRequestType]
           ,[ThemeColor]
           ,[UseInGlobalSearch]
           ,[WaitingOnMeIncludesGroups]
           ,[WaitingOnMeExcludesResolved]
           ,[Title]
           ,[AutoRefreshListFrequency]
           --,[AllowActualHoursByUser]
           ,[TenantID]
           ,[Created]
           ,[Modified]
           ,[CreatedByUser]
           ,[ModifiedByUser]
           ,[Deleted]
           ,[Attachments]
			)
     VALUES
           ( 0
           , 0
           ,0
           ,0
           ,0
           ,0
           ,0
           ,0
           ,0
           ,0
           ,0
           ,0
           , null
           , null
           , 0
           ,'Service Management'
           , null
           , null
           ,0
           ,0
           , 1
           ,0
           , 1
           ,0
           ,null
           ,0
           ,0
           ,0
           , 0
           , 0
           ,0
           , 0
           ,0
           ,1
           ,GETDATE()
           , 0
           ,'This module is used to create and manage help cards.'
           ,0
           ,372
           , 'HLP'
           , '/Pages/HelpCards'
           , 'HelpCard'
           , 2
           , ''
           , null
           , 'Auto'
           , 0
           , 0
           , 0
           , 0
           , 0
           ,'Help'
           , 0
           ,0
           ,0
           ,0
           ,'/Pages/HLP'
           ,0
           , 0
           ,'Accent1'
           , 0
           , 0
           ,0
           , 'Help (HLP)'
           , 0
           --,0
           ,  @TenantID
           , GETDATE()
           , GETDATE()
           ,  '00000000-0000-0000-0000-000000000000'
           ,  '00000000-0000-0000-0000-000000000000'
           ,0
           ,''
          )
END


set @i = @i + 1
end